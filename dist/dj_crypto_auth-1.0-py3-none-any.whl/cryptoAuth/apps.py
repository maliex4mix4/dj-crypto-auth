from django.apps import AppConfig


class CryptoauthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cryptoAuth'
